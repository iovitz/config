"""Code related to snippets."""
